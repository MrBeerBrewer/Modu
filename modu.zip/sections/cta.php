<?php $cta = getData('cta'); ?>

<section id="cta" class="py-20 bg-blue-600 text-white text-center">

    <h2 class="text-4xl font-bold mb-6">
        <?= $cta['title'] ?? '' ?>
    </h2>

    <a href="#contact"
       class="bg-white text-blue-600 px-6 py-3 rounded">
        <?= $cta['button'] ?? '' ?>
    </a>

</section>