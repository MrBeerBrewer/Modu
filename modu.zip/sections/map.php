<?php $map = getData('map'); ?>

<section id="map" class="py-16">

    <div class="container">

        <iframe
            src="<?= $map['embed'] ?? '' ?>"
            class="w-full h-96 rounded"
        ></iframe>

    </div>

</section>