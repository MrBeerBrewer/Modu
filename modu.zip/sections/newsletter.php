<?php $newsletter = getData('newsletter'); ?>

<section id="newsletter" class="py-16 bg-gray-100">

    <div class="container text-center">

        <h2 class="text-3xl font-bold mb-6">
            <?= htmlspecialchars($newsletter['title'] ?? 'Subscribe to our Newsletter') ?>
        </h2>

        <input
            type="email"
            placeholder="Your Email"
            class="border px-4 py-2 rounded"
        >

    </div>

</section>