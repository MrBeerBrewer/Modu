<?php

define('EXPORT_MODE', true);

ob_start();
include 'index.php';
$html = ob_get_clean();

// Force download
header('Content-Type: text/html');
header('Content-Disposition: attachment; filename="index.html"');
header('Content-Length: ' . strlen($html));

echo $html;
exit;