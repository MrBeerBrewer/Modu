<?php $footer = getData('footer'); ?>

<footer class="bg-gray-900 text-white py-10">

    <div class="container">

        <h3 class="text-2xl font-bold">
            <?= $footer['company'] ?? '' ?>
        </h3>

        <p class="mt-4">
            <?= $footer['description'] ?? '' ?>
        </p>

    </div>

</footer>