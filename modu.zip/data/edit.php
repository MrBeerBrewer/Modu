<?php

$files = glob("*.json");

// SAVE HANDLER
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $targetFile = $_POST["__file"] ?? '';

    // 🛡️ HARD SAFETY CHECK (important)
    if (!in_array($targetFile, glob("*.json"))) {
        die("Invalid file target");
    }

    if (file_exists($targetFile)) {

        $data = json_decode(file_get_contents($targetFile), true);

        if (is_array($data)) {

            foreach ($data as $key => $value) {

                if (!isset($_POST[$key])) continue;

                $input = $_POST[$key];

                // keep structure OR string
                $decoded = json_decode($input, true);

                if (json_last_error() === JSON_ERROR_NONE) {
                    $data[$key] = $decoded;
                } else {
                    $data[$key] = $input;
                }
            }

            
            
            // Create a backup before overwriting
if (file_exists($targetFile)) {
    copy($targetFile, $targetFile . '.bak');
}
            
            file_put_contents(
                $targetFile,
                json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)
            );

            echo "<p style='color:green;'>Saved: " . htmlspecialchars($targetFile) . "</p>";
        }
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>JSON CMS Editor</title>
</head>
<body style="font-family:Arial; padding:20px;">

<h2>📦 JSON Content Editor</h2>

<?php foreach ($files as $file): ?>

    <?php
        $data = json_decode(file_get_contents($file), true);
        if (!is_array($data)) continue;
    ?>

    <div style="border:1px solid #ddd; padding:15px; margin-bottom:20px;">

        <h3><?= htmlspecialchars($file) ?></h3>

        <form method="POST">

            <input type="hidden" name="__file" value="<?= htmlspecialchars($file) ?>">

            <?php foreach ($data as $key => $value): ?>

                <label style="font-weight:bold;">
                    <?= htmlspecialchars(ucfirst($key)) ?>
                </label><br>

                <?php if (is_array($value) || is_object($value)): ?>

                    <textarea 
                        name="<?= htmlspecialchars($key) ?>"
                        rows="8"
                        style="width:100%; margin-bottom:10px;"
                    ><?= htmlspecialchars(json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)) ?></textarea>

                <?php else: ?>

                    <input 
                        type="text"
                        name="<?= htmlspecialchars($key) ?>"
                        value="<?= htmlspecialchars($value) ?>"
                        style="width:100%; margin-bottom:10px;"
                    >

                <?php endif; ?>

            <?php endforeach; ?>

            <button type="submit">💾 Save <?= htmlspecialchars($file) ?></button>

        </form>

    </div>

<?php endforeach; ?>

</body>
</html>