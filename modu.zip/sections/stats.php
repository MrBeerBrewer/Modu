<?php

$stats = getData('stats');

?>

<section class="py-16 bg-blue-50">

    <div class="container">

        <h2 class="text-3xl font-bold text-center mb-10">
            <?= $stats['title'] ?? 'Our Achievements' ?>
        </h2>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">

            <?php foreach ($stats['items'] as $item): ?>

                <div class="bg-white p-6 rounded-lg shadow">

                    <div class="text-4xl font-bold text-blue-600">
                        <?= $item['number'] ?>
                    </div>

                    <div class="mt-2 text-gray-600">
                        <?= $item['label'] ?>
                    </div>

                </div>

            <?php endforeach; ?>

        </div>

    </div>

</section>