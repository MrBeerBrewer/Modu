<?php

$team = getData('team');

?>

<section id="team" class="py-16 bg-gray-50">

    <div class="container">

        <h2 class="text-3xl font-bold text-center mb-10">
            <?= $team['title'] ?? 'Our Team' ?>
        </h2>

        <div class="grid md:grid-cols-3 gap-6">

            <?php foreach (($team['members'] ?? []) as $member): ?>

                <div class="bg-white rounded-lg shadow overflow-hidden text-center">

                    <img
                        src="<?= $member['image'] ?? '' ?>"
                        alt="<?= $member['name'] ?? '' ?>"
                        class="w-full h-72 object-cover"
                    >

                    <div class="p-6">

                        <h3 class="text-xl font-bold">
                            <?= $member['name'] ?? '' ?>
                        </h3>

                        <p class="text-gray-600 mt-2">
                            <?= $member['position'] ?? '' ?>
                        </p>

                    </div>

                </div>

            <?php endforeach; ?>

        </div>

    </div>

</section>