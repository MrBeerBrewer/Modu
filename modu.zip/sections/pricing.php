<?php $pricing = getData('pricing'); ?>

<section id="pricing" class="py-16 bg-gray-50">
    <div class="container">
        <h2 class="text-3xl font-bold text-center mb-10">
            <?= $pricing['title'] ?? '' ?>
        </h2>

        <div class="grid md:grid-cols-3 gap-6">

            <?php foreach (($pricing['plans'] ?? []) as $plan): ?>

                <div class="bg-white p-6 rounded shadow text-center">

                    <h3 class="text-xl font-bold">
                        <?= $plan['name'] ?? '' ?>
                    </h3>

                    <div class="text-4xl font-bold my-4">
                        <?= $plan['price'] ?? '' ?>
                    </div>

                    <p>
                        <?= $plan['description'] ?? '' ?>
                    </p>

                </div>

            <?php endforeach; ?>

        </div>
    </div>
</section>