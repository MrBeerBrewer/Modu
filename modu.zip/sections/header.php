<?php

$header = getData('header');

?>

<header class="bg-white shadow">

    <div class="container mx-auto px-4 py-4 flex justify-between items-center">

        <h1 class="text-2xl font-bold">
            <?= $header['logo'] ?? 'Logo' ?>
        </h1>

        <nav class="flex gap-6">

            <?php foreach (($header['menu'] ?? []) as $item): ?>

                <a
                    href="<?= $item['url'] ?? '#' ?>"
                    class="hover:text-blue-600"
                >
                    <?= $item['title'] ?? 'Menu' ?>
                </a>

            <?php endforeach; ?>

        </nav>

    </div>

</header>