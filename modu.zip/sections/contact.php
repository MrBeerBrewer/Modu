<?php $contact = getData('contact'); ?>

<section id="contact" class="py-16">

    <div class="container">

        <h2 class="text-3xl font-bold mb-10">
            <?= $contact['title'] ?? '' ?>
        </h2>

        <p><strong>Phone:</strong> <?= $contact['phone'] ?? '' ?></p>
        <p><strong>Email:</strong> <?= $contact['email'] ?? '' ?></p>
        <p><strong>Address:</strong> <?= $contact['address'] ?? '' ?></p>

    </div>

</section>