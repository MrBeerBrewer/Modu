<?php $faq = getData('faq'); ?>

<section id="faq" class="py-16">
    <div class="container">
        <h2 class="text-3xl font-bold text-center mb-10">
            <?= $faq['title'] ?? '' ?>
        </h2>

        <?php foreach (($faq['items'] ?? []) as $item): ?>
            <div class="mb-6 bg-white p-6 rounded shadow">
                <h3 class="font-bold mb-2">
                    <?= $item['question'] ?? '' ?>
                </h3>
                <p>
                    <?= $item['answer'] ?? '' ?>
                </p>
            </div>
        <?php endforeach; ?>
    </div>
</section>