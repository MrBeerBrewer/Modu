<?php $copyright = getData('copyright'); ?>

<div class="bg-black text-white text-center py-4">

    <?= $copyright['text'] ?? '' ?>

</div>