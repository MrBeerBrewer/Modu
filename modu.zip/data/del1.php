<?php

$file = "contact.json";

// Load JSON → PHP array
$data = json_decode(file_get_contents($file), true);

// Handle save
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    foreach ($data as $key => $value) {
        if (isset($_POST[$key])) {
            $data[$key] = $_POST[$key];
        }
    }

    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));

    echo "<p style='color:green'>Saved successfully!</p>";
}
?>

<form method="POST">
    <?php foreach ($data as $key => $value): ?>
        
        <label>
            <?= ucfirst($key) ?>
        </label><br>

        <input 
            type="text"
            name="<?= $key ?>"
            value="<?= htmlspecialchars($value) ?>"
            style="margin-bottom:10px;width:300px"
        >
        <br>

    <?php endforeach; ?>

    <button type="submit">Save</button>
</form>