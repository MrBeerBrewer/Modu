<?php
$hero = getData('hero');
?>

<section class="bg-gray-100 py-20 text-center">

    <h2 class="text-5xl font-bold mb-4">
        <?= htmlspecialchars($hero['title'] ?? 'Hero Section') ?>
    </h2>

    <p class="text-lg text-gray-600 mb-6">
        <?= htmlspecialchars($hero['subtitle'] ?? 'Your amazing tagline goes here.') ?>
    </p>

    <div class="flex justify-center gap-4">
        <?php if (!empty($hero['button1_text'])): ?>
            <a href="<?= htmlspecialchars($hero['button1_link'] ?? '#') ?>"
               class="bg-blue-600 text-white px-6 py-3 rounded">
                <?= htmlspecialchars($hero['button1_text']) ?>
            </a>
        <?php endif; ?>

        <?php if (!empty($hero['button2_text'])): ?>
            <a href="<?= htmlspecialchars($hero['button2_link'] ?? '#') ?>"
               class="border border-blue-600 px-6 py-3 rounded">
                <?= htmlspecialchars($hero['button2_text']) ?>
            </a>
        <?php endif; ?>
    </div>

</section>