<?php

$portfolio = getData('portfolio');

?>

<section id="portfolio" class="py-16 bg-gray-50">

    <div class="container">

        <h2 class="text-3xl font-bold text-center mb-10">
            <?= $portfolio['title'] ?? 'Portfolio' ?>
        </h2>

        <div class="grid md:grid-cols-3 gap-6">

            <?php foreach (($portfolio['items'] ?? []) as $project): ?>

                <div class="bg-white rounded-lg shadow overflow-hidden">

                    <img
                        src="<?= $project['image'] ?? '' ?>"
                        alt="<?= $project['title'] ?? '' ?>"
                        class="w-full h-56 object-cover"
                    >

                    <div class="p-6">

                        <h3 class="text-xl font-bold mb-2">
                            <?= $project['title'] ?? '' ?>
                        </h3>

                        <p class="text-gray-600">
                            <?= $project['description'] ?? '' ?>
                        </p>

                    </div>

                </div>

            <?php endforeach; ?>

        </div>

    </div>

</section>