<?php

$process = getData('process');

?>

<section id="process" class="py-16 bg-gray-50">

    <div class="container">

        <h2 class="text-3xl font-bold text-center mb-10">
            <?= $process['title'] ?? 'Our Process' ?>
        </h2>

        <div class="grid md:grid-cols-4 gap-6">

            <?php foreach (($process['steps'] ?? []) as $index => $step): ?>

                <div class="bg-white p-6 rounded-lg shadow text-center">

                    <div class="text-2xl font-bold text-blue-600 mb-3">
                        <?= $index + 1 ?>
                    </div>

                    <div>
                        <?= $step ?>
                    </div>

                </div>

            <?php endforeach; ?>

        </div>

    </div>

</section>