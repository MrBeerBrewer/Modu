<?php

$files = glob("*.json");

// Handle save
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $targetFile = $_POST["__file"];

    $data = json_decode(file_get_contents($targetFile), true);

    foreach ($data as $key => $value) {
        if (isset($_POST[$key])) {
            $data[$key] = $_POST[$key];
        }
    }

    file_put_contents($targetFile, json_encode($data, JSON_PRETTY_PRINT));

    echo "<p style='color:green'>Saved: $targetFile</p>";
}

foreach ($files as $file):

    $data = json_decode(file_get_contents($file), true);

    if (!is_array($data)) continue;

?>

<h3><?= htmlspecialchars($file) ?></h3>

<form method="POST">

    <input type="hidden" name="__file" value="<?= htmlspecialchars($file) ?>">

    <?php foreach ($data as $key => $value): ?>

    <?php if (is_array($value) || is_object($value)) continue; ?>

    <label><?= htmlspecialchars(ucfirst($key)) ?></label><br>

    <input 
        type="text"
        name="<?= htmlspecialchars($key) ?>"
        value="<?= htmlspecialchars($value) ?>"
        style="margin-bottom:10px;width:300px"
    >
    <br>

<?php endforeach; ?>

    <button type="submit">Save <?= htmlspecialchars($file) ?></button>

</form>

<hr>

<?php endforeach; ?>