<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Modu Website Builder by Santosh Jadagoudar</title>

<script src="https://cdn.tailwindcss.com"></script>

<style>
.container{
    max-width:1200px;
    margin:auto;
    padding-left:1rem;
    padding-right:1rem;
}
</style>

</head>
<body>

    <?php if (!defined('EXPORT_MODE')): ?>
<a href="data/edit.php" target="_blank">Edit</a>
<a href="export.php" target="_blank">Export</a>
<?php endif; ?>

<?php

function getData($section)
{
    $file = "data/{$section}.json";

    if (!file_exists($file)) {
        return [];
    }

    return json_decode(
        file_get_contents($file),
        true
    );
}

$sections = [
    'topbar',
    'header',
    'hero',
    'logos',
    'stats',
    'features',
    'services',
    'why-us',
    'process',
    'portfolio',
    'testimonials',
    'pricing',
    'team',
    'faq',
    'cta',
    'contact',
    'map',
    'newsletter',
    'footer',
    'copyright'
];

foreach ($sections as $section) {
    include "sections/{$section}.php";
}

?>

</body>
</html>