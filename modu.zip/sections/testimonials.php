<?php

$testimonials = getData('testimonials');

?>

<section id="testimonials" class="py-16">

    <div class="container">

        <h2 class="text-3xl font-bold text-center mb-10">
            <?= $testimonials['title'] ?? 'Testimonials' ?>
        </h2>

        <div class="grid md:grid-cols-3 gap-6">

            <?php foreach (($testimonials['items'] ?? []) as $testimonial): ?>

                <div class="bg-white p-6 rounded-lg shadow">

                    <p class="text-gray-600 mb-4">
                        "<?= $testimonial['text'] ?? '' ?>"
                    </p>

                    <h3 class="font-bold">
                        <?= $testimonial['name'] ?? '' ?>
                    </h3>

                    <p class="text-sm text-gray-500">
                        <?= $testimonial['designation'] ?? '' ?>
                    </p>

                </div>

            <?php endforeach; ?>

        </div>

    </div>

</section>