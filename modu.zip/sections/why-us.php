<?php $why = getData('why-us'); ?>

<section id="why-us" class="py-16">

    <div class="container text-center">

        <h2 class="text-3xl font-bold mb-6">
            <?= $why['title'] ?? '' ?>
        </h2>

        <p>
            <?= $why['description'] ?? '' ?>
        </p>

    </div>

</section>