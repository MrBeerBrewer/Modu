<?php

$features = getData('features');

?>

<section id="features" class="py-16">

    <div class="container">

        <h2 class="text-3xl font-bold text-center mb-10">
            <?= $features['title'] ?? 'Features' ?>
        </h2>

        <div class="grid md:grid-cols-3 gap-6">

            <?php foreach (($features['items'] ?? []) as $feature): ?>

                <div class="bg-white p-6 rounded-lg shadow text-center">

                    <div class="text-xl font-semibold">
                        <?= $feature ?>
                    </div>

                </div>

            <?php endforeach; ?>

        </div>

    </div>

</section>