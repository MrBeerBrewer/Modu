<?php

$topbar = getData('topbar');

?>

<div class="bg-blue-600 text-white text-center py-2">

    <?= $topbar['text'] ?? 'Welcome to Our Website' ?>

</div>