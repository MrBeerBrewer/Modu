<?php

$services = getData('services');

?>

<section
    id="<?= $services['id'] ?? 'services' ?>"
    class="py-16 bg-gray-50"
>

    <div class="container">

        <h2 class="text-3xl font-bold text-center mb-10">
            <?= $services['title'] ?>
        </h2>

        <div class="grid md:grid-cols-3 gap-6">

            <?php foreach ($services['items'] as $service): ?>

                <div class="bg-white p-6 rounded-lg shadow">

                    <h3 class="text-xl font-bold mb-3">
                        <?= $service['title'] ?>
                    </h3>

                    <p>
                        <?= $service['description'] ?>
                    </p>

                </div>

            <?php endforeach; ?>

        </div>

    </div>

</section>