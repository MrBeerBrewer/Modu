<?php

$logos = getData('logos');

?>

<section class="py-16 bg-white">

    <div class="container">

        <h2 class="text-3xl font-bold text-center mb-10">
            <?= $logos['title'] ?? 'Our Clients' ?>
        </h2>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-8">

            <?php foreach ($logos['items'] as $logo): ?>

                <div class="text-center">

                    <img
                        src="<?= $logo['image'] ?>"
                        alt="<?= $logo['name'] ?>"
                        class="mx-auto h-16 object-contain"
                    >

                    <p class="mt-2 text-sm text-gray-600">
                        <?= $logo['name'] ?>
                    </p>

                </div>

            <?php endforeach; ?>

        </div>

    </div>

</section>